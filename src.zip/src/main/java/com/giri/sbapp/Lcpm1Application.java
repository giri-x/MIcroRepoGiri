package com.giri.sbapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lcpm1Application {

	public static void main(String[] args) {
		SpringApplication.run(Lcpm1Application.class, args);
	}

}
