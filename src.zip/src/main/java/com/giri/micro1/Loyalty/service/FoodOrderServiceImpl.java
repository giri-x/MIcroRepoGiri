package com.giri.micro1.Loyalty.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.giri.micro1.Loyalty.dao.FoodOrderDao;
import com.giri.micro1.Loyalty.model.FoodItemOrder;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class FoodOrderServiceImpl implements FoodOrderService {
	
	@Autowired
	FoodOrderDao dao;

	@Override
	public boolean insertOrder(FoodItemOrder order) {
		this.dao.addOrder(order);
		   return true;
	}

	@Override
	public boolean updateOrder(FoodItemOrder order) {
		dao.updateOrder(order);
		return true;
	}

	@Override
	public List<FoodItemOrder> findAllOrder() {
		return this.dao.listAllOrder();	}

	@Override
	public boolean deleteOrder(Long orderId) {
		dao.deleteOrder(orderId);
		return true;
	}

	@Override
	public FoodItemOrder findOrderById(Long orderId) {
		return dao.findOrderById(orderId);
	}

}
