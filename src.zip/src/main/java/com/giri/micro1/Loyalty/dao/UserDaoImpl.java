package com.giri.micro1.Loyalty.dao;

import java.util.List;
import java.util.Optional;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import com.giri.micro1.Loyalty.model.User;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Repository
@Transactional
@Service
public class UserDaoImpl implements UserDao {
	
	private EntityManager entityManager;
	
	

	public UserDaoImpl() {
		super();
		
	}
	
	@Autowired
	public UserDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}



	@Override
	public void addUser(User user) {
		
		 try {
	        	entityManager.persist(user);
	        }catch(Exception e) {
	            e.printStackTrace();
	        }
		
		
		
	}

	@Override
	public Optional<User> findbyemail(String email) {
		
		
		  return entityManager.createQuery("SELECT a FROM User a WHERE a.email = :email", User.class)
		              .setParameter("email", email)
		              .getResultStream()
		              .findFirst();
	}

	@Override
	public User userLogin(String email, String password) {
		Query q = (Query) entityManager.createQuery("from Customer log where log.email =?1 and log.password=?2");
		q.setParameter(1, email);
		q.setParameter(2, password);
		return (User) q.getSingleResult();
	}

	@Override
	public List<User> listAllUser() {
		List<User> userList =  entityManager.createQuery("from User").getResultList();
		return userList;
	}

}
