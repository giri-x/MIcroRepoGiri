package com.giri.micro1.Loyalty;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class LCPM1 {

	public static void main(String[] args) {
		SpringApplication.run(LCPM1.class, args);
	}

}
