package com.giri.micro1.Loyalty.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.giri.micro1.Loyalty.dao.UserDao;
import com.giri.micro1.Loyalty.model.User;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDao dao;

	@Override
	public boolean addUser(User user) {
		dao.addUser(user);
		return true;
	}

	@Override
	public Optional<User> findbyemail(String email) {
		return this.dao.findbyemail(email);
	}

	@Override
	public Optional<User> UserLogin(String email, String password) {
		return dao.findbyemail(email);
	}

	@Override
	public List<User> findAllUser() {
		return this.dao.listAllUser();
	}

}
