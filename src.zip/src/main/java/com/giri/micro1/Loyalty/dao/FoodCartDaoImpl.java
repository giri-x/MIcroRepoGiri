package com.giri.micro1.Loyalty.dao;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.giri.micro1.Loyalty.model.AdminProduct;
import com.giri.micro1.Loyalty.model.FoodItemCart;

import jakarta.persistence.EntityManager;

@Repository
public class FoodCartDaoImpl implements FoodCartDao {
	
	@Autowired
	private EntityManager entity;

	@Override
	public boolean validateCart(FoodItemCart cart) {
		try {
			AdminProduct adminProduct = cart.getAdminProduct();
			long prodId = adminProduct.getProductId();
			Query<FoodItemCart> query = (Query<FoodItemCart>) entity.createQuery("FROM FoodItemCart as cart where cart.sellerProduct.productId=:id");
			query.setParameter("id", prodId);
			FoodItemCart cart1 = query.getSingleResult();
			return true;
			
			}catch (Exception e) {
				return false;
			}

}
	

	@Override
	public FoodItemCart findCartById(Long cartId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateCart(FoodItemCart cart) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteOrder(Long cartId) {
		String msg = "";
		FoodItemCart cart = entity.find(FoodItemCart.class, cartId);
		try {
			entity.remove(cart);
			return msg = "deletion success";
		} catch (Exception e) {
			return msg = "deletion failure";
		}
	}

	@Override
	public List<FoodItemCart> listAllCart() {
		List<FoodItemCart> cartList = entity.createQuery("from FoodItemCart").getResultList();
		return cartList;

	}

	@Override
	public void insertCart(FoodItemCart cart) {
		System.err.println(cart);
		try {
			entity.persist(cart);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}


}
