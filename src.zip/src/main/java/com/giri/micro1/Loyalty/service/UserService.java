package com.giri.micro1.Loyalty.service;

import java.util.List;
import java.util.Optional;
import com.giri.micro1.Loyalty.model.User;

public interface UserService {
	
	public boolean addUser(User user);

	public Optional<User> findbyemail(String email);

	public Optional<User> UserLogin(String email, String password);
	
	List<User> findAllUser();

}
